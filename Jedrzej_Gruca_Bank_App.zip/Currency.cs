﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank_App
{
    enum Currency
    {
        PLN,
        USD,
        EUR
    }
}
